package ru.oneme.app

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class InfoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this)
        tv.text = "Это демонстрационное приложение. Оно не является официальным и используется для обучения."
        tv.setPadding(20, 20, 20, 20)
        setContentView(tv)
    }
}
