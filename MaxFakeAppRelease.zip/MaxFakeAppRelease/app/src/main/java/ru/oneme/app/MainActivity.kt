package ru.oneme.app

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private val PREFS_NAME = "user_prefs"
    private val KEY_CHOICE = "user_choice"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        val savedChoice = prefs.getString(KEY_CHOICE, null)

        if (savedChoice != null) {
            // Если выбор уже сохранён, запускаем действие сразу
            performAction(savedChoice)
            finish()
            return
        }

        setContentView(R.layout.activity_main)

        val btnCrash = findViewById<Button>(R.id.btnCrash)
        val btnFreeze = findViewById<Button>(R.id.btnFreeze)
        val btnBlockedAntivirus = findViewById<Button>(R.id.btnBlockedAntivirus)

        btnCrash.setOnClickListener {
            saveChoiceAndPerform("crash")
        }

        btnFreeze.setOnClickListener {
            saveChoiceAndPerform("freeze")
        }

        btnBlockedAntivirus.setOnClickListener {
            saveChoiceAndPerform("antivirus")
        }
    }

    private fun saveChoiceAndPerform(choice: String) {
        prefs.edit().putString(KEY_CHOICE, choice).apply()
        performAction(choice)
        finish()
    }

    private fun performAction(choice: String) {
        when (choice) {
            "crash" -> {
                // Например, вызвать исключение чтобы приложение упало
                throw RuntimeException("Приложение вылетело по выбору пользователя")
            }
            "freeze" -> {
                // Зависание - простой бесконечный цикл
                while(true) { }
            }
            "antivirus" -> {
                // Запуск активности с "фейковым антивирусом"
                val intent = Intent(this, AntivirusActivity::class.java)
                startActivity(intent)
            }
            else -> {
                // Ничего не делать
            }
        }
    }
}
