package ru.oneme.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AntivirusActivity : AppCompatActivity() {

    private val antivirusName = "TrustDefender"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_antivirus)

        val tvTitle = findViewById<TextView>(R.id.tvAntivirusTitle)
        val tvMessage = findViewById<TextView>(R.id.tvAntivirusMessage)
        val btnWhy = findViewById<Button>(R.id.btnWhy)
        val btnHowTo = findViewById<Button>(R.id.btnHowTo)
        val btnDelete = findViewById<Button>(R.id.btnDelete)

        tvTitle.text = "Встроенный антивирус ($antivirusName)"
        tvMessage.text = "Приложение заблокировано антивирусом $antivirusName за следящие модули."

        btnWhy.setOnClickListener {
            val url = "https://github.com/ZolManStaff/MAX-deep-analysis-of-the-messenger"
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }

        btnHowTo.setOnClickListener {
            tvMessage.text = "Никак, по причине что оно содержит вирусы."
        }

        btnDelete.setOnClickListener {
            tvMessage.text = "Если удалить антивирус $antivirusName, телефон превратится в кирпич."
            Handler().postDelayed({
                throw RuntimeException("Антивирус $antivirusName не может быть удалён. Приложение аварийно завершает работу.")
            }, 5000)
        }
    }
}
